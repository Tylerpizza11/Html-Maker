The folder name in which you compile this in will be the application name. The icon.png present in this folder will be the app icon/logo.

Make sure you have devkitPro before compiling!

   -DarkFlare